package com.smart.controller;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.Entity.User;
import com.smart.config.Message;
import com.smart.dao.UserRepository;

@Controller
public class homecontroller 
{
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	 private UserRepository userrepo;

@RequestMapping("/")
public String home(Model model)
{
model.addAttribute( "title", "Home- contact manager");
 return "home";

 }
@RequestMapping("/signup")
public String signup(Model model)
{
model.addAttribute( "title","Register-smart contact manager");
model.addAttribute("user",new User());
 return "signup";

 
}


//for registration
@RequestMapping(value="/do_register",method=RequestMethod.POST)
public String register(@ModelAttribute("user") User user,@RequestParam(value="agreement",defaultValue="false")boolean agreement , Model model , HttpSession session)
{
	try
	{
		if(!agreement)
		{
			System.out.println("you have not agree terms and condition");
			throw new Exception("you have not agree terms and condition");
		}
		user.setRole("ROLE_USER");
		user.setEnable(true);
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		System.out.println("Agreement"+agreement);
		System.out.println("User"+user);
	    User result =this.userrepo.save(user);
		model.addAttribute("user",result);
		session.setAttribute("message", new Message("Succesfully Register","alert-Success"));
		return "signup";
	}catch(Exception e)
	{
		e.printStackTrace();
		model.addAttribute("user", user);
	session.setAttribute("message", new Message("Something Went Wrong","alert-danger "));
	return "signup";
	}
	}

//Login
@RequestMapping("/login")
public String login(Model model)
{
	model.addAttribute("title","Login-smart contact manager");
	return "login";

	
}

}




	