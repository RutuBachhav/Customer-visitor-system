package com.smart.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.smart.Entity.Contact;
import com.smart.Entity.User;
import com.smart.config.Message;
import com.smart.dao.ContactRepository;
import com.smart.dao.UserRepository;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserRepository userrepo;
	@Autowired
	private ContactRepository contactrepo;

	@RequestMapping("/user_dashboard")
	@PreAuthorize("hasRole(ROLE_USER)")
	public String Dashboard(HttpSession session) {

		return "user_dashboard";

	}

	@GetMapping("/add_user")
	public String Add_user(Model model)

	{
		model.addAttribute("contact", new Contact());
		return "user/add_contact";

	}

	// processing add contact form

	@PostMapping("/process-contact")

	public String processcontact(@ModelAttribute Contact contact, Principal principal) {

		String name = principal.getName();
		User user = this.userrepo.getuserByUsername(name);
		user.getContacts().add(contact);
		this.userrepo.save(user);
		System.out.println("DATA" + contact);

		return "user/add_contact";
	}

	@GetMapping("/show_contact")
	public ModelAndView show_contact()

	{
		ModelAndView mav = new ModelAndView("user/show_contact");
		List<Contact> contacts = this.contactrepo.findAll();
		mav.addObject("contacts", contacts);
		return mav;

	}
	//delete contact
	
	@GetMapping("/delete/{cid}")
	public String deletecontact(@PathVariable("cid")Integer cid,Model model , HttpSession session)
	{
		Optional<Contact> contactoptional=this.contactrepo.findById(cid);
		Contact contact = contactoptional.get();
		contact.setUser(null);
		this.contactrepo.delete(contact);
		session.setAttribute("message", new Message("Contact deleted the succesfully..." , "success"));
		return "redirect:/user/show_contact";
	}
	//update
	@RequestMapping("/update_contact/{cid}")
	public String updateform(@PathVariable("cid")Integer cid,Model model )
	{
		Optional<Contact> contactoptional=this.contactrepo.findById(cid);

		Contact contact = contactoptional.get();
		model.addAttribute("Contact", contact);
		return "user/update_form";
		
	}
	//contact handeler
	@RequestMapping( value = "/process-update", method= RequestMethod.POST)
	public String updatehandeler(@ModelAttribute Contact contact , HttpSession session ,Principal principal)
	{
		System.out.println("CONTACT NAME"+contact.getCname());
	 
		User user = this.userrepo.getuserByUsername(principal.getName());
		contact.setUser(user);

		this.contactrepo.save(contact);
		session.setAttribute("message", new Message("Contact deleted the succesfully..." , "success"));
return "redirect:/user/show_contact";
	}
	
	@RequestMapping("/{cid}/contact")
	public String showcontactdetails (@PathVariable("cid")Integer cid , Model model)
	{
		System.out.println("DATA" + cid);
	
		Optional<Contact> contactoptional=this.contactrepo.findById(cid);

		Contact contact = contactoptional.get();
		model.addAttribute("Contact", contact);
		return "user/contact_details";
	}

	@GetMapping("/profile")
	public String profile( )
	{

		//String name = principal.getName();
	//User user1 = this.userrepo.getById(id);
		//this.userrepo.save(user);
//		//userrepo.findOne(null);
//		Optional<User> contactoptional=this.userrepo.findById(id);
//		User user = contactoptional.get();
//		model.addAttribute("user", user);

		return "user/profile";
	}

}
