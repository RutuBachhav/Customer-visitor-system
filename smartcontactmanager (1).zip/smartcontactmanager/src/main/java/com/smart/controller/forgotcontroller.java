package com.smart.controller;

import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.Entity.User;
import com.smart.dao.UserRepository;
import com.smart.service.Email_Service;

@Controller
public class forgotcontroller {
	Random random = new Random(1000);
	@Autowired
	private Email_Service emailservice;
	@Autowired
	private UserRepository userrepo;
	@Autowired
	private BCryptPasswordEncoder bcr;

	@RequestMapping("/forgot")
	public String email() {
		return "forgot_email";
	}

	@PostMapping("/send-otp")
	public String otp(@RequestParam("email") String email, HttpSession session) {
		System.out.println("EMAIL" + email);

		int otp = random.nextInt(9999);
		System.out.println("OTP" + otp);

		String subject = "OTP From Smart Contact Manager";
		String message =  "OTP=  " + otp  ;
		String to = email;

		boolean flag = this.emailservice.sendEmail(subject, message, to);
		if (flag) {
			session.setAttribute("email", email);
			session.setAttribute("otp", otp);
		
		

			return "verify_otp";

		} else {
			session.setAttribute("message", "check your email id");
			return "forgot_email";
		}

	}
	@PostMapping("/verify_otp")
	public String verify(@RequestParam("otp") int otp,HttpSession session)
	{
int myotp=(int)session.getAttribute("otp");
String email= (String)session.getAttribute("email");
if(myotp==otp)
{
	User user = this.userrepo.getuserByUsername(email);
	if(user==null)
	{
		//send error message
		session.setAttribute("message", "User does not Exist!!");
		return "forgot_email";
	}else
	{
		// send change password form
	
	}
	
return	"user/password_change_form";

}else
{
	session.setAttribute("message", "You have enter wrong otp");
	return "verify_otp";
}
}
	@PostMapping("/change_password")
	public String changepassword(@RequestParam("newpassword") String newpassword, HttpSession session)
	
	{
		String email= (String)session.getAttribute("email");
		User user = this.userrepo.getuserByUsername(email);
		user.setPassword(this.bcr.encode(newpassword));
		this.userrepo.save(user);
		return "redirect:/login?change=password change succesfully......";
		//return "login";
	}
}

