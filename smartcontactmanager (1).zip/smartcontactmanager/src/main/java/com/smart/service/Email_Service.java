package com.smart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.util.Properties;

import javax.mail.*;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@Service
public class Email_Service {
	
	@Autowired 
	JavaMailSender javaMailSender;
	
	public boolean sendEmail(String subject, String message, String to)

	{
		boolean f = false;
		String from = "rutubachhav1@gmail.com";
		String host = "smtp.gmail.com";

		Properties properties = System.getProperties();

		properties.put("mail.smtp", host);

		properties.put("mail.smtp.port", "465");

		properties.put("mail.smtp.ssl.enable", true);

		System.out.println(properties);

		MimeMessage m = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(m);
		try {
			helper.setFrom(from);
			helper.setTo(new InternetAddress(to));
			helper.setSubject(subject);
			helper.setText(message);
			javaMailSender.send(m);
			System.out.println("send");
			f = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
}
