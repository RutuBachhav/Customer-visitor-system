package com.smart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smart.Entity.Contact;

public interface ContactRepository extends JpaRepository<Contact, Integer>
{

	
	
}
