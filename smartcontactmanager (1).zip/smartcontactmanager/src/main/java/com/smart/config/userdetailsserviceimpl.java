package com.smart.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.smart.Entity.User;
import com.smart.dao.UserRepository;

public class userdetailsserviceimpl implements UserDetailsService
{
	@Autowired
	private UserRepository userrepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException 
	{
		
		User user=userrepo.getuserByUsername(username);
		if(user==null)
		{
		throw new UsernameNotFoundException("Could not find the user");
		
		}
		customuserdetails customuser = new customuserdetails(user);
		return customuser;
	
	}

}
