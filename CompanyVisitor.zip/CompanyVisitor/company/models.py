from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class Visitor(models.Model):
    fullname = models.CharField(max_length=100)
    emailid = models.CharField(max_length=100)
    mobileno = models.CharField(max_length=15)
    address = models.CharField(max_length=500)
    whomtomeet = models.CharField(max_length=100)
    department = models.CharField(max_length=100)
    reasontomeet = models.CharField(max_length=100)
    vdate = models.DateField()
    intime = models.CharField(max_length=50)
    remark = models.CharField(max_length=500, null=True)
    outtime = models.CharField(max_length=50, null=True)
    def __str__(self):
        return self.fullname



