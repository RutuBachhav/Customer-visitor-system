from django.db.models import Q
from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from django.contrib import messages
from datetime import date
from datetime import datetime, timedelta, time
# Create your views here.

def Index(request):
    error = ""
    if request.method == 'POST':
        u = request.POST['username']
        p = request.POST['password']
        user = authenticate(username=u, password=p)
        try:
            if user.is_staff:
                login(request,user)
                error = "no"
            else:
                error = "yes"
        except:
            error = "yes"
    d = {'error': error}
    return render(request, 'index.html', d)



def admin_home(request):
    if not request.user.is_authenticated:
        return redirect('index')
    today = datetime.now().date()
    yesterday = today - timedelta(1)
    lasts = today - timedelta(7)

    tv = Visitor.objects.filter(vdate=today).count()
    yv = Visitor.objects.filter(vdate=yesterday).count()
    ls = Visitor.objects.filter(vdate__gte=lasts,vdate__lte=today).count()
    totalv = Visitor.objects.all().count()

    d = {'tv':tv,'yv':yv,'ls':ls,'totalv':totalv}
    return render(request,'admin_home.html',d)


def new_visitor(request):
    if not request.user.is_authenticated:
        return redirect('index')
    error = ""
    if request.method=="POST":
        fn = request.POST['fullname']
        em = request.POST['email']
        mn = request.POST['mobilenumber']
        ad = request.POST['address']
        wt = request.POST['whomtomeet']
        dp = request.POST['department']
        rm = request.POST['reasontomeet']
        dt = request.POST['date']
        it = request.POST['intime']
        try:
            Visitor.objects.create(fullname=fn,emailid=em,mobileno=mn,address=ad,whomtomeet=wt,department=dp,reasontomeet=rm,vdate=dt,intime=it,remark='',outtime='')
            error = "no"
        except:
            error = "yes"
    d = {'error':error}
    return render(request, 'new_visitor.html', d)


def manage_visitor(request):
    if not request.user.is_authenticated:
        return redirect('index')
    visitor = Visitor.objects.all()
    d = {'visitor':visitor}
    return render(request, 'manage_visitor.html', d)


def visitor_detail(request,pid):
    if not request.user.is_authenticated:
        return redirect('login')
    error = ""
    visitor = Visitor.objects.get(id=pid)
    if request.method == 'POST':
        rm = request.POST['remark']
        ot = request.POST['outtime']
        try:
            visitor.remark = rm
            visitor.outtime = ot
            visitor.save()
            error = "no"
        except:
            error = "yes"

    d = {'visitor': visitor,'error':error}
    return render(request,'visitor_detail.html', d)



def Logout(request):
    logout(request)
    return redirect('index')


def changepassword(request):
    if not request.user.is_authenticated:
        return redirect('index')
    error = ""
    if request.method=="POST":
        o = request.POST['currentpassword']
        n = request.POST['newpassword']
        c = request.POST['confirmpassword']
        if c == n:
            u = User.objects.get(username__exact=request.user.username)
            u.set_password(n)
            u.save()
            error = "yes"
        else:
            error = "not"
    d = {'error':error}
    return render(request,'changepassword.html',d)




def betweendate_reportdetails(request):
    if not request.user.is_authenticated:
        return redirect('index')
    return render(request, 'betweendate_reportdetails.html')



def betweendate_report(request):
    if not request.user.is_authenticated:
        return redirect('index')
    if request.method == "POST":
        fd = request.POST['fromdate']
        td = request.POST['todate']
        visitor = Visitor.objects.filter(Q(vdate__gte=fd) & Q(vdate__lte=td))
        visitorcount = Visitor.objects.filter(Q(vdate__gte=fd) & Q(vdate__lte=td)).count()
        d = {'visitor': visitor,'fd':fd,'td':td,'visitorcount':visitorcount}
        return render(request, 'betweendate_reportdetails.html', d)
    return render(request, 'betweendate_report.html')


def search(request):
    q = request.GET.get('searchdata')

    try:
        visitor = Visitor.objects.filter(Q(fullname__icontains=q) | Q(mobileno__icontains=q)).distinct()
        visitorcount = Visitor.objects.filter(Q(fullname__icontains=q) | Q(mobileno__icontains=q)).distinct().count()

    except:
        visitor = ""
    d = {'visitor': visitor,'q':q,'visitorcount':visitorcount}
    return render(request, 'search.html',d)

